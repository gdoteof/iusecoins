=== About Ubercart Coupons ===

This module was created to work with the Ubercart ecommerce module for Drupal.


=== About the Authors ===

Original Author

Blake Lucchesi
blake@boldsource.com
www.boldsource.com


Drupal 5 Maintenance

David Long
dave@longwaveconsulting.com


Drupal 6 Port

Jordan of Cubicle Collective
jordan@gocubeco DAWT com


Coupon Reports Sponsored by: Oasis Day Spa - http://www.oasisdayspanyc.com
